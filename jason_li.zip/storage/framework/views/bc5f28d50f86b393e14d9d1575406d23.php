

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3">
        <h5 class="m-0">Projects</h5>
        <form method="post" action="<?php echo e(route('projects.store')); ?>" class="d-flex align-items-center gap-2">
            <?php echo csrf_field(); ?>
            <input type="text" class="form-control" name="name" placeholder="New project name" required>
            <button type="submit" class="btn btn-primary">Add Project</button>
        </form>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if($projects->isEmpty()): ?>
        <div class="alert alert-secondary">No projects yet.</div>
    <?php else: ?>
        <div class="list-group">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item d-flex align-items-center justify-content-between">
                    <form method="post" action="<?php echo e(route('projects.update', $project)); ?>" class="d-flex align-items-center gap-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <input type="text" name="name" class="form-control" value="<?php echo e($project->name); ?>" required>
                        <button class="btn btn-sm btn-outline-success" type="submit">Save</button>
                    </form>
                    <div class="d-flex align-items-center gap-2">
                        <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('tasks.index', ['project_id' => $project->id])); ?>">Open</a>
                        <form method="post" action="<?php echo e(route('projects.destroy', $project)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Simba\Documents\CODE\OGG\laravel\resources\views/projects/index.blade.php ENDPATH**/ ?>