

<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-3">
        <div class="d-flex align-items-center gap-2">
            <form method="get" action="<?php echo e(route('tasks.index')); ?>" id="projectFilterForm" class="d-flex align-items-center gap-2">
                <label for="project_id" class="form-label m-0">Project:</label>
                <select class="form-select" id="project_id" name="project_id" onchange="document.getElementById('projectFilterForm').submit()">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($project->id); ?>" <?php if($project->id === $selectedProjectId): echo 'selected'; endif; ?>><?php echo e($project->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
            <a class="btn btn-outline-secondary" href="<?php echo e(route('projects.index')); ?>">Manage Projects</a>
        </div>
        <?php if($selectedProjectId): ?>
            <form method="post" action="<?php echo e(route('tasks.store')); ?>" class="d-flex align-items-center gap-2">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="project_id" value="<?php echo e($selectedProjectId); ?>">
                <input type="text" class="form-control" name="name" placeholder="New task name" required>
                <button type="submit" class="btn btn-primary">Add Task</button>
            </form>
        <?php endif; ?>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if($projects->isEmpty()): ?>
        <div class="alert alert-info">
            No projects yet. Create one on the <a href="<?php echo e(route('projects.index')); ?>">Projects</a> page.
        </div>
    <?php elseif($selectedProjectId && $tasks->isEmpty()): ?>
        <div class="alert alert-secondary">No tasks for this project yet.</div>
    <?php else: ?>
        <ul id="task-list" class="list-group">
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex align-items-center justify-content-between" data-id="<?php echo e($task->id); ?>">
                    <div class="d-flex align-items-center gap-2">
                        <span class="badge text-bg-secondary"><?php echo e($task->priority); ?></span>
                        <form method="post" action="<?php echo e(route('tasks.update', $task)); ?>" class="d-flex align-items-center gap-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="project_id" value="<?php echo e($selectedProjectId); ?>">
                            <input type="text" name="name" class="form-control" value="<?php echo e($task->name); ?>" required>
                            <button class="btn btn-sm btn-outline-success" type="submit">Save</button>
                        </form>
                    </div>
                    <form method="post" action="<?php echo e(route('tasks.destroy', $task)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php if($selectedProjectId && $tasks->isNotEmpty()): ?>
    <script>
        const list = document.getElementById('task-list');
        if (list) {
            new Sortable(list, {
                animation: 150,
                onEnd: () => {
                    const order = Array.from(list.querySelectorAll('li')).map(li => parseInt(li.dataset.id, 10));
                    fetch('<?php echo e(route('tasks.reorder')); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': window.csrfToken,
                        },
                        body: JSON.stringify({
                            project_id: <?php echo e($selectedProjectId); ?>,
                            order: order
                        })
                    }).then(() => {
                        // After reorder, reload to refresh priority badges
                        window.location.reload();
                    });
                }
            });
        }
    </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Simba\Documents\CODE\OGG\laravel\resources\views/tasks/index.blade.php ENDPATH**/ ?>